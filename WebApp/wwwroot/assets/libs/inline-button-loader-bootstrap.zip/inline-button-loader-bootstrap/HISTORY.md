# Release History

## 1.0.2

* Reverted fix :-/

## 1.0.1

* Fixed `<button>` disabled on click

## 1.0.0

* First release
